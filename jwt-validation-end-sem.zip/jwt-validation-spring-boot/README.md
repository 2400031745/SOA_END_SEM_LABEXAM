# JWT Verification and Claims Extraction (Spring Boot)

A small Spring Boot 3.5 / Java 21 project for the workbook task:
1. Validate a JWT signature with a secret key.
2. Reject expired or malformed tokens.
3. Extract username, role, issue time and expiration claims.
4. Test the endpoints through Swagger UI.

## Requirements
- JDK 21
- Maven 3.6+ (or import `pom.xml` into IntelliJ IDEA and let Maven resolve dependencies)
- Internet access for the first Maven dependency download

## Import and run (IntelliJ IDEA)
1. Extract this ZIP.
2. Open IntelliJ IDEA -> Open -> select the extracted `jwt-validation-spring-boot` folder.
3. Trust the project and wait for Maven dependencies to download.
4. Open `src/main/java/com/example/jwtvalidation/JwtValidationApplication.java`.
5. Click the green Run icon beside `main()`.

Alternatively, from the project folder run:
```bash
mvn spring-boot:run
```

## Swagger test
Open:
http://localhost:8080/swagger-ui/index.html

### 1. Generate a demo token
Execute `GET /api/token/generate` and copy the `token` value.

### 2. Validate and extract claims
Execute `GET /api/token/validate`.
In the `Authorization` header enter:
`Bearer <paste-the-token-here>`

Expected result: HTTP 200 and JSON containing `valid`, `username`, `role`, `issuedAt`, and `expiration`.

### 3. Invalid / expired token
Send a modified token or an expired token. Expected result: HTTP 401.
Omit the Authorization header to test a missing token. Expected result: HTTP 401.

## Code locations
- `JwtService.java`: signing key, demo token generation, signature/expiration validation and claims extraction.
- `JwtController.java`: REST endpoints.
- `application.properties`: port and demo secret key.
- `pom.xml`: Spring Web, JJWT and Swagger dependencies.

Note: `/generate` is included only as a classroom testing helper. A production system should issue tokens only after authenticating a user, and should keep its signing secret in an environment variable or secret manager.
